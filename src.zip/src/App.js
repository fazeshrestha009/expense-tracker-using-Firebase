import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import ExpenseForm from './components/ExpenseForm';
import ExpenseList from './components/ExpenseList';

function App() {
  const [expenses, setExpenses] = useState([]);

  // Function to add a new expense
  const addExpense = (expense) => {
    setExpenses((prevExpenses) => [...prevExpenses, expense]);
  };

  return (
    <div className="flex min-h-screen bg-gray-900 text-white">
      {/* Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <div className="flex-1 p-6">
        <h1 className="text-3xl font-bold mb-6">Expense Tracker</h1>

        {/* Expense Form */}
        <ExpenseForm onAddExpense={addExpense} />

        {/* Expense List */}
        <ExpenseList expenses={expenses} />
      </div>
    </div>
  );
}

export default App;
